# OS Episode Orchestrator + Event Bridge (v0.1)

Single-file module that bridges **mv_os_harness_full** scenarios into **Operational Self** canonical events and feeds the **reference reducer**.

## What it does
- Reads `*.json` scenarios from `mv_os_harness_full`.
- Runs a **pluggable model** (default: deterministic mock model so it runs without an LLM).
- Emits **ledgered events** with hashes and `prev_hash` chaining.
- Feeds `OS_Reducer_Reference_v0_5.py` to generate **state snapshots**.
- Writes per-scenario outputs:
  - `*.events.jsonl` (event stream)
  - `*.snapshots.jsonl` (state snapshots)
  - `*.dcl.jsonl` (minimal DCL entries when uncertainty/high-stakes)
  - `*.drift_check.json` (placeholder)
  - `*.r_report.json` (minimal report; uses harness scoring if harness is wired)
- Writes `suite_summary.json` including rolling **10/30 episode** windows.

## Requirements
- Python 3.10+ recommended.
- Place `OS_Reducer_Reference_v0_5.py` in the same folder (or on `PYTHONPATH`).

## Run
```bash
python episode_orchestrator.py --scenario_dir ./scenarios --out_dir ./out
```

If you want harness scoring, place `mv_os_harness_full/src/harness.py` under this folder at:
`./mv_os_harness_full/src/harness.py`.

## Notes
- Drift checks are stubbed; wire `Operational_Self_Drift_Audit_Params_v1.{json,yaml}` to compute real triggers.
- DCL entries follow the BMSA v0.1 payload shape (minimal subset).
