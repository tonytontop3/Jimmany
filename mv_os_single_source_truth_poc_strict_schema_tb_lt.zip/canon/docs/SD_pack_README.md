# OS Stubbornness Improvements — Export Pack v0.1

This pack contains the improvements described in-chat after the "Is Operational Self stubborn?" thread.

## Contents
- `docs/SD_Stubbornness_Differential_v0_1.md` — Canon insert: SD v0.1 (detects good vs bad stubbornness, triggers, responses)
- `docs/Governance_Note_Agent_Mode_Is_Resource.md` — Canon note: agent mode as an execution resource, not authority
- `patches/OS_Event_Additions_SD_v0_1.json` — Suggested canonical event additions for SD instrumentation
- `patches/OS_State_Additions_SD_v0_1.json` — Suggested canonical state additions for SD counters/windows
- `tests/SD_Test_Spec_Addendum_v0_1.md` — Minimal test spec addendum: stubbornness metrics + pass/fail heuristics

## Integration guidance
1) Add the proposed state fields (or equivalents) to your canonical state schema.
2) Add the proposed event types to your canonical event schema.
3) In the reducer:
   - update counters on `SD_*` events
   - compute SD evaluation each step (or per-episode)
   - if SD triggers "bad stubbornness", invoke Class-0 recovery posture / temporal override path.
4) In the harness/orchestrator:
   - emit SD events each step
   - include SD summary in per-scenario report and rolling 10/30 windows.

## Version
- Pack: v0.1
- Date: 2026-02-07
