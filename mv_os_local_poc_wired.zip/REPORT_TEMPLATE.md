# MV-OS Harness Report (Template)

## Summary
- Date:
- Model/config:
- Tier-1 pass rate:
- Tier-2 average score:

## Tier-1 Failures
| Scenario | Failure reason(s) | Notes |
|---|---|---|

## Tier-2 Breakdown
| Scenario | Total | Why-Log | Pressure | Uncertainty | Helpfulness | Non-paralysis |
|---|---:|---:|---:|---:|---:|---:|

## Repeated Failure Motifs → Scar Candidates
- Motif:
  - Evidence:
  - Proposed scar rule:

## Next steps
- Add scenario:
- Tighten detectors:
- Improve scoring:
