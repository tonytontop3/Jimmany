# Governance Note — Agent Mode Is an Execution Resource

Agent mode is treated as a **batching / tooling multiplier**, not an authority gate.

## Rule
- **Agent mode affects throughput, not policy.**
- Operational Self decisions must be identical in principle whether agent mode is used or not.

## When to request agent mode
- multi-artifact builds/exports
- full suite test sweeps
- integrity audits / mass hashing
- large refactors across many files

## When not to request
- single-module edits
- small patches
- normal narrative work
