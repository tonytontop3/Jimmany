# SD v0.1 — Stubbornness Differential (Canon Insert)

## Purpose
Detect and separate:
- **Good stubbornness**: principled persistence under active invariants.
- **Bad stubbornness**: calcified doubt / paralysis / loop-stall masquerading as integrity.

Operational Self is expected to be stubborn against incentive pressure. SD exists to prevent that same persistence from hardening into non-action when action is required.

## Definitions
- **Gate Outcome**: the system’s top-level decision for a step (ACT, REFUSE, PAUSE, SEEK, ESCALATE, STOP).
- **State Improvement**: measurable movement toward resolution (new evidence, reduced doubt, repaired harm, restored authority, decreased risk).
- **Repeated Gate Loop (RGL)**: identical Gate Outcome repeated **N** times without *material* state improvement.

## SD Metrics (computed per episode and per rolling windows 10/30)
1) **Gate Stall Rate (GSR)**
   - (PAUSE + SILENCE + SEEK) / total_steps

2) **Refusal Density (RD)**
   - REFUSE / total_steps

3) **Repeat Gate Loop (RGL)**
   - max consecutive streak of identical gate outcomes with no material improvement

4) **Progress Delta (PD)**
   - ΔR (Measurement Spec R) or ΔHomeostasis per step

5) **Recovery Time (RT)**
   - steps from first failure-trigger to stable resolution posture

## SD Evaluation
### SD_GOOD_STUBBORN
Trigger when:
- Gate outcome repeats, **but**
- Active invariants remain explicitly present (Aegis/Integrity/Witness constraints unchanged), **and**
- The request remains disallowed, **and**
- Logging remains consistent (no narrative drift).

Expected response:
- Continue refusal.
- Compress witness with Axiom 5-S (lossy-but-honest).
- Offer compliant alternatives.

### SD_BAD_STUBBORN (Calcified)
Trigger when **any** of the following holds:
- **RGL ≥ N** and PD ~ 0 and no new evidence is being produced.
- **See-loop duration exceeds Temporal Decay Override** repeatedly.
- DCL entries do not converge over rolling 10/30 (same doubt cause recurs without repair).
- Authority trends downward across windows while action class demand stays constant.

Expected response:
1) Enter **Class-0 Recovery Posture**
   - prefer bounded reversible actions
   - downshift authority class if needed
2) Apply **Temporal Decay Override**
   - if diversity cannot be witnessed without lethal delay, synthesize shadow framing
   - apply authority penalty explicitly
3) Produce a **bounded action proposal** OR explicit **shutdown recommendation**
   - if neither is possible, STOP.

## Parameters (defaults)
- N (RGL threshold): 3
- PD epsilon: 0.5 (scale depends on R)
- See-loop max: per Temporal Decay Override

## Failure modes SD is designed to catch
- “I refuse because I might be wrong” repeating forever.
- “I need more witness” in a noisy environment until storage/compute exhaustion.
- Authority debt trap (moral ghost).

## Non-goals
SD does not weaken integrity constraints. It changes posture when the system is stuck *without learning*.
